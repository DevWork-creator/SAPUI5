sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox"
], function(Controller, JSONModel, formatter, Filter, FilterOperator, Fragment, MessageBox) {
	"use strict";

	return Controller.extend("com.nitinGridAsTable.controller.Main", {

		onInit: function() {
			var oRowModel1 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel2 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel3 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel4 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel5 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel6 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel7 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel8 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel9 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel10 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel11 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel12 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel13 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel14 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel15 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			var oRowModel16 = new JSONModel({
				"Value": "No",
				"AttachDocuments": "",
				"Visible": false
			});
			//var oModel12 = new sap.ui.model.json.JSONModel(data12.Details);
			this.getView().setModel(oRowModel1, "Row01");
			this.getView().setModel(oRowModel2, "Row02");
			this.getView().setModel(oRowModel3, "Row03");
			this.getView().setModel(oRowModel4, "Row04");
			this.getView().setModel(oRowModel5, "Row05");
			this.getView().setModel(oRowModel6, "Row06");
			this.getView().setModel(oRowModel7, "Row07");
			this.getView().setModel(oRowModel8, "Row08");
			this.getView().setModel(oRowModel9, "Row09");
			this.getView().setModel(oRowModel10, "Row10");
			this.getView().setModel(oRowModel11, "Row11");
			this.getView().setModel(oRowModel12, "Row12");
			this.getView().setModel(oRowModel13, "Row13");
			this.getView().setModel(oRowModel14, "Row14");
			this.getView().setModel(oRowModel15, "Row15");
			this.getView().setModel(oRowModel16, "Row16");
			var linkTextAPAN1 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal1: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN1, "linkTextAPAN1");
			var linkTextAPAN2 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal2: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN2, "linkTextAPAN2");
			var linkTextAPAN3 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal3: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN3, "linkTextAPAN3");
			var linkTextAPAN4 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal4: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN4, "linkTextAPAN4");
			var linkTextAPAN5 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal5: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN5, "linkTextAPAN5");
			var linkTextAPAN6 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal6: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN6, "linkTextAPAN6");
			var linkTextAPAN7 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal7: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN7, "linkTextAPAN7");
			var linkTextAPAN8 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal8: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN8, "linkTextAPAN8");
			var linkTextAPAN9 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal1: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN9, "linkTextAPAN9");
			var linkTextAPAN10 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal2: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN10, "linkTextAPAN10");
			var linkTextAPAN11 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal3: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN11, "linkTextAPAN11");
			var linkTextAPAN12 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal4: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN12, "linkTextAPAN12");
			var linkTextAPAN13 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal5: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN13, "linkTextAPAN13");
			var linkTextAPAN14 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal6: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN14, "linkTextAPAN14");
			var linkTextAPAN15 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal7: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN15, "linkTextAPAN15");
			var linkTextAPAN16 = new JSONModel({
				text: "",
				Path: "",
				visible: false,
				text1: "",
				Path1: "",
				visible1: false,
				text2: "",
				Path2: "",
				fileuploadPanVal: "",
				fileuploadPanVal8: "",
				fileuploadLinkText: "",
				visible2: false

			});
			this.getView().setModel(linkTextAPAN16, "linkTextAPAN16");
		},
		handleChangeComBoxRec: function(oEvent) {
			//debugger;
			var oGetModelName = oEvent.getParameters().id.slice(14, 19);
			this.onChangeCmBx(oGetModelName);
		},
		onChangeCmBx: function(oModelName) {
			var oData = this.getView().getModel(oModelName).getData();
			/*	for (var i = 0; i < oData.length; i++) {
					var Data = oData[i];*/
			if (oData.Value === 'Yes') {
				oData.Visible = true;
			} else if (oData.Value === 'No') {
				oData.Visible = false;
			}
			/*	}*/
		},
		fileUpload: function(oEvent) {
			var modelName = oEvent.getSource().getName();
			this.handleUploadCompletePan(oEvent, modelName);
		},
		handleUploadCompletePan: function(oEvent, modelName) {
			var that = this;
			var src = oEvent.getSource();
			src.setValueState("None");
			src.setValueStateText("");
			var fileDetails = oEvent.getParameters("file").files[0];

			if (fileDetails) {
				var mimeDet = fileDetails.type,
					fileName = fileDetails.name,
					fileSize = fileDetails.size;
			}
			var src = oEvent.getSource(),
				internameFileName = src.getName();
			var fileDetails = oEvent.getParameters("file").files[0],
				linkpath = URL.createObjectURL(fileDetails);
			var model = this.getView().getModel(modelName).getData();
			if (fileName.length > 25) {
				var fileName = fileName.slice(0, 25);
			}
			model.text1 = fileName;
			model.fileuploadLinkText = fileName;
			model.Path1 = linkpath;
			model.visible1 = true;
			this.getView().getModel(modelName).updateBindings();
			//this.removeMessageFromTarget3("/"+fileuploadPan);
		},
		onpdfLinkOpenPressPAN1: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN1");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach1: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN1").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN1").updateBindings();
		},
		onpdfLinkOpenPressPAN2: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN2");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach2: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN2").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN2").updateBindings();
		},
		onpdfLinkOpenPressPAN3: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN3");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach3: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN3").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN3").updateBindings();
		},
		onpdfLinkOpenPressPAN4: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN4");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach4: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN4").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN4").updateBindings();
		},
		onpdfLinkOpenPressPAN5: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN5");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach5: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN5").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN5").updateBindings();
		},
		onpdfLinkOpenPressPAN6: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN6");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach6: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN6").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN6").updateBindings();
		},
		onpdfLinkOpenPressPAN7: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN7");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach7: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN7").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN7").updateBindings();
		},
		onpdfLinkOpenPressPAN8: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN8");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach8: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN8").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN8").updateBindings();
		},
		onpdfLinkOpenPressPAN9: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN9");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach9: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN9").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN9").updateBindings();
		},
		onpdfLinkOpenPressPAN10: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN10");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach10: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN10").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN10").updateBindings();
		},
		onpdfLinkOpenPressPAN11: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN11");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach11: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN11").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN11").updateBindings();
		},
		onpdfLinkOpenPressPAN12: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN12");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach12: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN12").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN12").updateBindings();
		},
		onpdfLinkOpenPressPAN13: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN13");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach13: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN13").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN13").updateBindings();
		},
		onpdfLinkOpenPressPAN14: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN14");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach14: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN14").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN14").updateBindings();
		},
		onpdfLinkOpenPressPAN15: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN15");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach15: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN15").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN15").updateBindings();
		},
		onpdfLinkOpenPressPAN16: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN16");
			//var path = oEvent.getSource().getBindingContext("linkTextAPAN").getPath();
			//var idx = parseInt(path.substring(path.lastIndexOf('/') + 1)),
			//modelData = model.getData()[idx];
			var path1 = model.getData().Path1;
			sap.m.URLHelper.redirect(path1, true);
		},
		deletePANCArdAttach16: function(oEvent) {
			var model = this.getView().getModel("linkTextAPAN16").getData();
			model.Path1 = "";
			model.fileuploadPanVal = "";
			model.visible1 = false;
			this.getView().getModel("linkTextAPAN16").updateBindings();
		},

	});
});