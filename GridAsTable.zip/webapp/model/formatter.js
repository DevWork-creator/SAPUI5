jQuery.sap.declare("com.irdai.surveyorindividual.model.formatter");
sap.ui.define([], function () {
    "use strict";

    com.irdai.surveyorindividual.model.formatter = {

        /**
         * Rounds the number unit value to 2 digits
         * @public
         * @param {string} sValue the number string to be rounded
         * @returns {string} sValue with 2 digits rounded
         */
        numberUnit : function (sValue) {
            if (!sValue) {
                return "";
            }
            return parseFloat(sValue).toFixed(2);
        },
        messagePopOverFormat: function (type , cus) {
            if (type.toLowerCase() === "e") {
                if (cus) {
                    return "Mandatory field can't be blank" + " : " + cus;
                }
            } else if (type.toLowerCase() === "s") {
                return "Success";
            } else if (type.toLowerCase() === "w") {
                return "Warning";
            } else if (type.toLowerCase() === "i") {
                return "Information";
            }
        },

    };

});